<html><title>Logged out</title>
<?php
echo "<h1>Logged out</h1>";
echo "You will be redirected to the login in a few seconds";
header('Refresh: 5; index.php');
?>
</html>